import React from 'react';

import {DashboardLayout} from '../components/Layout';

const ProjectsPage = () => {
  return (
    <DashboardLayout>
      <h2>Projects Page</h2>
    </DashboardLayout>
  )
}

export default ProjectsPage;