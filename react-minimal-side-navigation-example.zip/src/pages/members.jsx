import React from 'react';

import {DashboardLayout} from '../components/Layout';

const MembersPage = () => {
  return (
    <DashboardLayout>
      <h2>Members Page</h2>
    </DashboardLayout>
  )
}

export default MembersPage;